S = 0
N = int(input())

for i in range(1, N+1):
    S += i ** 3

print('Сумма равна', S)