S = 0
N = int(input())

for i in range(1, N+1):
    print(i)
    S += i

print('Сумма равна', S)